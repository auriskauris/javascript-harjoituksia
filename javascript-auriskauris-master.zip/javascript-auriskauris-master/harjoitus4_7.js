function yhteenlasku() {
    alert("Avaa kehittäjänäkymä painamalla F12");
    let luku1 = Number(prompt("Syötä luku"))
    let luku2 = Number(prompt("Syötä toinen luku"))
    let yhteenlasku = luku1+luku2
    console.log(yhteenlasku);
    
}