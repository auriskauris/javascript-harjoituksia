var x = 0
function nappi() {
    x++;
    console.log(x);
    alert("Katso painamalla F12");
}