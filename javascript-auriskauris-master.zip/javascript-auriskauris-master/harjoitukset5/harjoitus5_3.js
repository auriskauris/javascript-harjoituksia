function kolmas() {
    for (let i = 0; i <= 100; i++) {
        if (i % 3 == 0) {
            console.log (i);
        } 
    }
}
kolmas();