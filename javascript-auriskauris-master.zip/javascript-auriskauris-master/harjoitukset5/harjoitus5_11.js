function anna() {
    while (true) {
    let x = Number(prompt("Anna luku:"));
       if (x == -1) {
           alert("Kiitos ja näkemiin!");
           break;
       }
    }
}