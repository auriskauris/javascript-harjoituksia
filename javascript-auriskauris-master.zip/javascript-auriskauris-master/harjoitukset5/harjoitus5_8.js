function mihin() {
    let x = prompt("Mihin asti?");
    let i = 1;
    while (i < x) {
      text += "<br>" + i;
      i++;
    }