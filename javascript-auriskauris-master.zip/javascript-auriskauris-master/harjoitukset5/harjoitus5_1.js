function potenssi() {
    for (let i = 1; i <= 10; i++) {
        let x = i**2
        console.log(x)
      }
}
potenssi();