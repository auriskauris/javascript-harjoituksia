function kerto() {
    for (let i = 1; i <= 10; i++) {
        for (let p = 1; p <= 20; p++) {
            let x = i*p
            console.log(x);
        }
    }
}
kerto();