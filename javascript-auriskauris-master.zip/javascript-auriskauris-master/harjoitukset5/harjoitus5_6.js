function lotto() {
    i = 0;
    while (i<7) {
        console.log(Math.floor(Math.random()*38)+1);
        i++;
  }
}