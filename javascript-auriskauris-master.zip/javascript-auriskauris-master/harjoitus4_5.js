function tervetuloa() {
    alert("Tervetuloa maailmaani");
}